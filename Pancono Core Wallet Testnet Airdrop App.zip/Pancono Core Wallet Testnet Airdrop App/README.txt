🟡 Pancono Core Wallet Airdrop – Testnet Phase 

Welcome to **Pancono Core**, the official blockchain node software powering the Pancono decentralized network.

Githhub/ Social media links:

https://chaserod.github.io/pancono-site-earnings/
https://chaserod.github.io/Pancono-Site/
https://chaserod.github.io/Pancono_app_site/
https://chaserod.github.io/pancono_testnet_site/

Main Bot: https://t.me/PanconoWallet_Bot?start
https://t.me/PanconoAirdropBot?start
https://t.me/PanconoAppBot?start


### 📌 Current Release

Version: **Testnet & Airdrop Phase – v1.0**
Status: **Public Mining Enabled**
Duration: **26 Nov 2025 onwards** Check our telegram channel to know update on later phase and mainnet airdrop launch date.

 

## 🚀 What is Pancono Core?

Pancono Core allows users to participate in the Pancono blockchain by:

* Mining testnet PANNO coins
* Verifying and relaying transactions
* Supporting decentralization and network growth

> Note: Testnet coins do **NOT** represent real monetary value.
> Contributions during the testnet help determine **future mainnet allocation**.

---

## 🔧 How to Run Pancono Core

### 🖥 Windows

1. Download and unzip the folder.
2. Double-click pancono_core.exe`to run.
3. The terminal will open and begin syncing/genesis initialization.



🌐 P2P Connectivity

You may notice no peers connected during testnet**.
This is expected — P2P connections will activate during the mainnet launch.


🪙 Reward System (Testnet → Mainnet)

Your mainnet token allotment increases with:

* Mining activity
* App usage
* Inviting friends.
* Social media engagement

> The most active users gain the **highest rewards** during mainnet migration.



💛 Thanks for Supporting the Testnet

Your contribution strengthens the Pancono ecosystem.
Together, we are building a fast, scalable, community-driven decentralized network.


Help Pancono Grow — Share & Earn Future Benefits

Pancono is a community-driven project. The more our community grows, the stronger the ecosystem becomes — and the greater the rewards for early testers & contributors.


If you enjoy using this Testnet App and believe in the future of Pancono:

🔥 Support Us by Sharing

Help us spread the word by:

Inviting your friends and crypto groups

Sharing the app on Twitter / X, Facebook, Telegram, Discord, WhatsApp, Instagram

Posting your mining screenshots, progress, or proof-of-earnings

⚠ Disclaimer

This is testnet app and may contain experimental features.

Testnet coins do not represent financial value.





## 🇮🇩 Indonesian (Bahasa Indonesia)

### 🟡 Pancono Core — Fase Testnet

Selamat datang di **Pancono Core**, perangkat lunak node resmi yang menjalankan jaringan blockchain Pancono.

Pancono Core memungkinkan Anda untuk:

* ⛏ Menambang koin **PANNO Testnet**
* 🔗 Memverifikasi dan menyebarkan transaksi
* 🌍 Mendukung desentralisasi dan pertumbuhan jaringan

> ⚠ Koin Testnet **tidak memiliki nilai finansial nyata**.
> Aktivitas Anda selama testnet akan membantu menentukan **alokasi token mainnet di masa depan**.

#### ⚙ Cara Menjalankan di Windows

1. Unduh dan ekstrak folder
2. Klik dua kali **`pancono_core.exe`**
3. Terminal akan terbuka dan mulai melakukan sinkronisasi

#### 🪙 Sistem Reward (Testnet → Mainnet)

Semakin aktif Anda, semakin besar alokasi token Mainnet:

* Aktivitas penambangan
* Penggunaan aplikasi
* Mengundang teman
* Aktivitas media sosial

#### 🤝 Bantu Pancono Tumbuh

Dukung proyek ini dengan:

* Mengajak teman dan komunitas crypto
* Membagikan aplikasi di **Twitter / X, Telegram, Discord, Facebook, WhatsApp, Instagram**
* Membagikan screenshot hasil penambangan atau progres

Setiap dukungan dari Anda memperkuat ekosistem — dan meningkatkan keuntungan Anda di masa depan.

---

## 🇪🇸 Spanish (Español)

### 🟡 Pancono Core — Fase Testnet

Bienvenido a **Pancono Core**, el software oficial de nodos que impulsa la red blockchain Pancono.

Con Pancono Core puedes:

* ⛏ Minar monedas **PANNO de Testnet**
* 🔗 Verificar y retransmitir transacciones
* 🌍 Contribuir a la descentralización y expansión de la red

> ⚠ Las monedas de Testnet **no tienen valor financiero real**.
> Tu participación durante el testnet influirá en tu **asignación futura de tokens en Mainnet**.

#### ⚙ Cómo ejecutar en Windows

1. Descarga y descomprime la carpeta
2. Haz doble clic en **`pancono_core.exe`**
3. Se abrirá la terminal y comenzará la sincronización

#### 🪙 Sistema de Recompensas (Testnet → Mainnet)

Cuanto más activo seas, mayor será tu asignación en el Mainnet:

* Actividad de minería
* Uso de la app
* Invitar amigos
* Participación en redes sociales

#### 🤝 Ayuda a que Pancono Crezca

Apóyanos compartiendo:

* Invita a tus amigos y comunidades cripto
* Comparte la app en **Twitter / X, Telegram, Discord, Facebook, WhatsApp, Instagram**
* Sube capturas de tus resultados de minería o progreso

Tu apoyo fortalece la red y aumenta tus futuros beneficios.

---

## 🇵🇭 Filipino (Tagalog)

### 🟡 Pancono Core — Testnet Phase

Maligayang pagdating sa **Pancono Core**, ang opisyal na blockchain node software ng Pancono network.

Sa Pancono Core maaari kang:

* ⛏ Mag-mine ng **PANNO Testnet coins**
* 🔗 Mag-verify at mag-relay ng mga transaksyon
* 🌍 Tumulong sa paglago at decentralization ng network

> ⚠ Ang mga Testnet coin ay **walang tunay na pinansyal na halaga**.
> Ang iyong aktibidad sa testnet ay magiging basehan sa **Mainnet token rewards sa hinaharap**.

#### ⚙ Paano Patakbuhin sa Windows

1. I-download at i-extract ang folder
2. I-double click ang **`pancono_core.exe`**
3. Magbubukas ang terminal at magsisimulang mag-sync

#### 🪙 Reward System (Testnet → Mainnet)

Mas mataas ang magiging reward mo sa Mainnet kung:

* Madalas kang mag-mine
* Madalas gumamit ng app
* Nag-iimbita ng mga kaibigan
* Nagsi-share sa social media

#### 🤝 Tulungan Lumago ang Pancono

Suportahan ang proyekto sa mga paraan na ito:

* I-invite ang friends at crypto communities
* I-share ang app sa **Twitter / X, Telegram, Discord, Facebook, WhatsApp, Instagram**
* Mag-post ng screenshots ng mining progress mo

Mas lumalakas ang ecosystem habang lumalaki ang community — at mas malaki rin ang magiging future rewards mo.


🇫🇷 French (Français)
🟡 Pancono Core — Phase Testnet

Bienvenue dans Pancono Core, le logiciel officiel de nœud alimentant le réseau blockchain Pancono.

Avec Pancono Core, vous pouvez :

⛏ Miner des jetons PANNO Testnet

🔗 Vérifier et relayer des transactions

🌍 Soutenir la décentralisation et la croissance du réseau

⚠ Les jetons Testnet n'ont pas de valeur financière réelle.
Votre activité pendant la phase Testnet influence vos récompenses lors du lancement du Mainnet.

⚙ Comment utiliser sous Windows

Téléchargez et décompressez le dossier

Double-cliquez sur pancono_core.exe

Le terminal s’ouvrira et commencera la synchronisation

🪙 Système de récompenses (Testnet → Mainnet)

Votre allocation future augmente grâce à :

L’activité de minage

L’utilisation régulière de l’application

L’invitation d’amis

L’engagement sur les réseaux sociaux

🤝 Aidez Pancono à grandir

Soutenez le projet en :

Invitant vos amis et communautés crypto

Partageant l’application sur Twitter/X, Telegram, Discord, Facebook, WhatsApp, Instagram

Publiant des captures d’écran et vos progrès

Plus la communauté est grande, plus l’écosystème — et vos futurs avantages — se développent.

🇯🇵 Japanese (日本語)
🟡 Pancono Core — テストネットフェーズ

Pancono Core へようこそ。これは Pancono ブロックチェーンネットワークを支える公式ノードソフトウェアです。

Pancono Core でできること：

⛏ PANNO テストネットコインの採掘

🔗 トランザクションの検証とリレー

🌍 ネットワークの分散化と拡大の支援

⚠ テストネットコインは 実際の金銭的価値を持ちません。
テストネットでの活動は メインネット移行時の報酬に影響します。

⚙ Windows での使用方法

フォルダをダウンロードして解凍

pancono_core.exe をダブルクリック

端末が起動し、同期が開始されます

🪙 報酬システム (Testnet → Mainnet)

報酬は次の行動で増加：

採掘アクティビティ

アプリの利用

友達を招待

SNS でのエンゲージメント

🤝 Pancono の成長を応援

次の方法でプロジェクトを支援できます：

友達や暗号通貨コミュニティを招待する

Twitter / X, Telegram, Discord, Facebook, Instagram, WhatsApp に共有

マイニングのスクリーンショットや進捗を投稿

より大きなコミュニティ = より強いエコシステムと高い将来報酬。

🇩🇪 German (Deutsch)
🟡 Pancono Core — Testnet-Phase

Willkommen bei Pancono Core, der offiziellen Nodesoftware des Pancono-Blockchain-Netzwerks.

Mit Pancono Core können Sie:

⛏ PANNO-Testnet-Coins minen

🔗 Transaktionen validieren und weiterleiten

🌍 Die Dezentralisierung und das Wachstum des Netzwerks unterstützen

⚠ Testnet-Coins besitzen keinen realen finanziellen Wert.
Ihre Aktivität im Testnet beeinflusst Ihre zukünftige Mainnet-Zuteilung.

⚙ Nutzung unter Windows

Ordner herunterladen und entpacken

pancono_core.exe doppelklicken

Das Terminal öffnet sich und beginnt zu synchronisieren

🪙 Belohnungssystem (Testnet → Mainnet)

Ihre Belohnung steigt durch:

Mining-Aktivität

Nutzung der App

Freunde einladen

Social-Media-Engagement

🤝 Helfen Sie Pancono zu wachsen

Unterstützen Sie uns:

Laden Sie Freunde und Krypto-Communities ein

Teilen Sie die App auf Twitter/X, Telegram, Discord, Facebook, WhatsApp, Instagram

Posten Sie Mining-Screenshots und Fortschritte

Eine größere Community bedeutet ein stärkeres Ökosystem — und mehr zukünftige Vorteile für Sie.

🇵🇹 Portuguese (Português — Brasil)
🟡 Pancono Core — Fase Testnet

Bem-vindo ao Pancono Core, o software oficial de nó que alimenta a rede blockchain Pancono.

Com o Pancono Core você pode:

⛏ Minerar moedas PANNO Testnet

🔗 Validar e retransmitir transações

🌍 Apoiar a descentralização e o crescimento da rede

⚠ As moedas Testnet não têm valor financeiro real.
Sua participação no Testnet influencia as recompensas no lançamento do Mainnet.

⚙ Como executar no Windows

Baixe e extraia a pasta

Clique duas vezes em pancono_core.exe

O terminal abrirá e iniciará a sincronização

🪙 Sistema de recompensas (Testnet → Mainnet)

Ganhos futuros aumentam com:

Atividade de mineração

Uso do aplicativo

Convites para amigos

Engajamento nas redes sociais

🤝 Ajude o Pancono a crescer

Apoie o projeto:

Convide amigos e comunidades cripto

Compartilhe o app no Twitter/X, Telegram, Discord, Facebook, Instagram, WhatsApp

Poste capturas da mineração e progresso

Quanto maior a comunidade — mais forte o ecossistema e melhores as recompensas futuras.

🇰🇷 Korean (한국어)
🟡 Pancono Core — 테스트넷 단계

Pancono 블록체인 네트워크를 구동하는 공식 노드 소프트웨어 Pancono Core에 오신 것을 환영합니다.

Pancono Core로 할 수 있는 것:

⛏ PANNO 테스트넷 코인 채굴

🔗 거래 검증 및 릴레이

🌍 네트워크 분산화 및 성장 지원

⚠ 테스트넷 코인은 실제 금전적 가치를 가지지 않습니다.
테스트넷 활동은 메인넷 보상에 영향을 미칩니다.

⚙ Windows 실행 방법

폴더 다운로드 및 압축 해제

pancono_core.exe 더블 클릭

터미널에서 동기화가 시작됩니다

🪙 보상 시스템 (Testnet → Mainnet)

보상 증가 요인:

채굴 활동

앱 사용

친구 초대

SNS 참여

🤝 Pancono 성장에 도움주세요

프로젝트를 지원하는 방법:

친구 및 크립토 커뮤니티 초대

Twitter/X, Telegram, Discord, Facebook, Instagram, WhatsApp 공유

채굴 화면 및 진행 상황 업로드

커뮤니티가 클수록 생태계가 강해지고, 미래 보상도 증가합니다.

🇻🇳 Vietnamese (Tiếng Việt)
🟡 Pancono Core — Giai đoạn Testnet

Chào mừng bạn đến với Pancono Core, phần mềm node chính thức của mạng blockchain Pancono.

Với Pancono Core, bạn có thể:

⛏ Đào PANNO Testnet

🔗 Xác thực & chuyển tiếp giao dịch

🌍 Hỗ trợ phi tập trung và mở rộng mạng lưới

⚠ Token Testnet không có giá trị tiền tệ thực.
Đóng góp Testnet ảnh hưởng đến phần thưởng khi ra mắt Mainnet.

⚙ Cách sử dụng trên Windows

Tải xuống và giải nén

Nhấp đúp pancono_core.exe

Terminal sẽ mở và bắt đầu đồng bộ

🪙 Hệ thống phần thưởng (Testnet → Mainnet)

Phần thưởng tăng khi bạn:

Đào thường xuyên

Sử dụng ứng dụng

Mời bạn bè

Tương tác mạng xã hội

🤝 Hỗ trợ Pancono phát triển

Hãy hỗ trợ bằng cách:

Mời bạn bè & cộng đồng crypto

Chia sẻ ứng dụng trên Twitter/X, Telegram, Discord, Facebook, Zalo, Instagram

Đăng ảnh chụp kết quả đào coin

Cộng đồng càng lớn — phần thưởng tương lai càng cao.

🇹🇭 Thai (ภาษาไทย)
🟡 Pancono Core — ระยะทดสอบ Testnet

ยินดีต้อนรับสู่ Pancono Core ซอฟต์แวร์โหนดอย่างเป็นทางการของเครือข่ายบล็อกเชน Pancono

คุณสามารถทำสิ่งต่อไปนี้ได้:

⛏ ขุด เหรียญ PANNO Testnet

🔗 ตรวจสอบและรีเลย์ธุรกรรม

🌍 สนับสนุนการกระจายศูนย์และการเติบโตของเครือข่าย

⚠ เหรียญ Testnet ไม่มีมูลค่าทางการเงินจริง
การมีส่วนร่วมของคุณจะมีผลต่อ รางวัลเมื่อเปิดตัว Mainnet

⚙ วิธีใช้งานบน Windows

ดาวน์โหลดและแตกไฟล์โฟลเดอร์

ดับเบิลคลิก pancono_core.exe

หน้าต่าง Terminal จะเปิดและเริ่มซิงค์

🪙 ระบบรางวัล (Testnet → Mainnet)

รางวัลจะเพิ่มขึ้นจาก:

การขุดอย่างต่อเนื่อง

การใช้งานแอป

การชวนเพื่อน

การมีส่วนร่วมบนโซเชียล

🤝 ช่วยให้ Pancono เติบโต

สนับสนุนเราโดย:

ชวนเพื่อนและกลุ่มคริปโต

แชร์แอปบน Twitter/X, Telegram, Discord, Facebook, Instagram, WhatsApp

โพสต์ภาพและความคืบหน้าการขุด

ยิ่งชุมชนใหญ่ — ระบบยิ่งแข็งแกร่ง และผลตอบแทนของคุณยิ่งมากในอนาคต

🇷🇺 Russian (Русский)
🟡 Pancono Core — Тестнет Фаза

Добро пожаловать в Pancono Core, официальное программное обеспечение узлов, обеспечивающее работу блокчейна Pancono.

С Pancono Core вы можете:

⛏ Майнить тестнет-монеты PANNO

🔗 Проверять и ретранслировать транзакции

🌍 Поддерживать децентрализацию и рост сети

⚠ Тестнет-монеты не имеют реальной финансовой ценности.
Ваша активность в тестнете влияет на будущие начисления токенов в мейннете.

⚙ Как запустить на Windows

Скачать и распаковать архив

Открыть двойным кликом pancono_core.exe

Терминал запустится и начнёт синхронизацию

🪙 Система вознаграждений (Тестнет → Мейннет)

Ваши будущие награды увеличиваются при:

Активном майнинге

Регулярном использовании приложения

Приглашении друзей

Активности в социальных сетях

🤝 Помогите Pancono расти

Поддержите проект:

Приглашайте друзей и крипто-сообщества

Делитесь приложением в Twitter / X, Telegram, Discord, Facebook, WhatsApp, Instagram

Публикуйте скриншоты майнинга и свой прогресс

Ваше участие усиливает сеть — и увеличивает ваши будущие выгоды.

🇨🇳 Chinese (中文 — 简体)
🟡 Pancono Core — 测试网阶段

欢迎使用 Pancono Core，这是驱动 Pancono 区块链网络的官方节点软件。

使用 Pancono Core 您可以：

⛏ 挖掘 PANNO 测试网代币

🔗 验证并转发交易

🌍 促进网络的去中心化与发展

⚠ 测试网代币 不代表真实货币价值。
您在测试网阶段的贡献将影响 主网空投与未来分配。

⚙ Windows 使用步骤

下载并解压文件夹

双击 pancono_core.exe

系统终端将启动并开始同步

🪙 奖励机制（测试网 → 主网）

主网奖励将根据以下行为提升：

挖矿活跃度

App 使用频率

邀请好友加入

社交媒体互动

🤝 帮助 Pancono 成长

支持我们的方法：

邀请好友和加密社区

分享应用至 微博、Telegram、Discord、Facebook、Twitter/X、Instagram、WhatsApp

发布挖矿截图或收益进度

社区越大，生态越强，未来收益越高。

🇹🇷 Turkish (Türkçe)
🟡 Pancono Core — Testnet Aşaması

Pancono Core’a hoş geldiniz — Pancono blockchain ağını çalıştıran resmi node yazılımı.

Pancono Core ile:

⛏ PANNO Testnet coinlerini kazabilirsiniz

🔗 İşlemleri doğrulayabilir ve iletebilirsiniz

🌍 Ağın merkeziyetsizliğine ve büyümesine katkı sağlayabilirsiniz

⚠ Testnet coinleri gerçek finansal değere sahip değildir.
Testnet sürecindeki katkılarınız Mainnet token ödüllerini etkileyecektir.

⚙ Windows’ta Nasıl Çalıştırılır

Klasörü indirin ve çıkarın

pancono_core.exe dosyasına çift tıklayın

Terminal açılacak ve senkronizasyon başlayacaktır

🪙 Ödül Sistemi (Testnet → Mainnet)

Ne kadar aktifsiniz, Mainnet ödülleriniz o kadar yüksek:

Madencilik aktivitesi

Uygulama kullanımı

Arkadaş davet etme

Sosyal medya etkileşimi

🤝 Pancono’nun Büyümesine Destek Olun

Bize destek olmak için:

Arkadaşlarınızı ve kripto topluluklarını davet edin

Uygulamayı Twitter / X, Telegram, Discord, Facebook, WhatsApp, Instagram üzerinden paylaşın

Madencilik ekran görüntülerinizi ve ilerlemenizi paylaşın

Topluluk büyüdükçe ekosistem de güçlenir — ve gelecekteki kazançlarınız artar.



🔹 Hindi (हिंदी)

पैनकोनो कोर — टेस्टनेट चरण में आपका स्वागत है

यह सॉफ्टवेयर आपको टेस्टनेट PANNO कॉइन माइनिंग, ट्रांज़ैक्शन वेरिफिकेशन और नेटवर्क को सपोर्ट करने की अनुमति देता है।

टेस्टनेट कॉइन वास्तविक आर्थिक मूल्य नहीं रखते लेकिन आपकी टेस्टनेट गतिविधि का उपयोग मुख्य नेटवर्क (Mainnet) के रिवॉर्ड वितरण में किया जाएगा।

👉 अधिक माइन करें, मित्रों को आमंत्रित करें, सोशल मीडिया पर शेयर करें — मुख्य नेटवर्क पर सबसे अधिक पुरस्कार पाने का मौका बढ़ाएँ।

🔥 ऐप को अपने दोस्तों और क्रिप्टो ग्रुप्स में शेयर करें ताकि हमारी कम्युनिटी बढ़े और आपके रिवॉर्ड भी बढ़ें।


🔹 Arabic (العربية)

مرحبًا بكم في Pancono Core — مرحلة الشبكة التجريبية (Testnet)

يتيح لك هذا البرنامج تعدين عملات PANNO التجريبية والتحقق من المعاملات ودعم اللامركزية.

عملات الشبكة التجريبية لا تمثل قيمة مالية حقيقية ولكن نشاطك التجريبي سيتم أخذُه بعين الاعتبار عند توزيع مكافآت الشبكة الرئيسية (Mainnet).

👉 كلما زاد نشاطك — التعدين، استخدام التطبيق، دعوة الأصدقاء، المشاركة على وسائل التواصل — زادت مكافأتك المستقبلية.

🔥 شارك التطبيق مع أصدقائك ومنصات التواصل الاجتماعي لدعم نمو المشروع وزيادة فرص مكافأتك.

